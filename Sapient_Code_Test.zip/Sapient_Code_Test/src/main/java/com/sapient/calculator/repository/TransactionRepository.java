package com.sapient.calculator.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.boot.autoconfigure.data.cassandra.CassandraRepositoriesAutoConfiguration;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import com.sapient.calculator.model.TransactionModel;

public interface TransactionRepository extends CassandraRepository<TransactionModel, String> {

	@Query("select * from TransactionModel where externalTransactionId=0? ,clientId=1?,securityId=2?" )
	public TransactionModel getData(String externalTransactionId, String clientId, String securityId );
	

}
