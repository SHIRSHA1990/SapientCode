package com.sapient.calculator.service;

import java.util.List;

import com.sapient.calculator.model.TransactionModel;

public interface TransactionService {

	public void IntraDayTransactionCalculation(TransactionModel model);
	
	public void NormalTransaction(TransactionModel model);
	
	public TransactionModel readDataFromExcel();
	
	public TransactionModel saveData();
	
	public TransactionModel getData(String externalTransactionId, String clientId, String securityId);
}
