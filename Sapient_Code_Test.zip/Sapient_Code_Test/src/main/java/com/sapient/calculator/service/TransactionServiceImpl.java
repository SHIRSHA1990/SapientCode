package com.sapient.calculator.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;

//import com.datastax.driver.core.Row;
import com.sapient.calculator.model.TransactionModel;
import com.sapient.calculator.repository.TransactionRepository;
import com.sapient.calculator.util.TransactionUtil;

public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private TransactionModel transactionModel;

	@Autowired
	private TransactionUtil transactionUtil;
	
	@Autowired
	private TransactionRepository transactionRepository;

	List<TransactionModel> transactions = new ArrayList<>();

	public void IntraDayTransactionCalculation(TransactionModel model) {

		transactions.forEach(t -> {
			if (t.getClientId().equalsIgnoreCase(model.getClientId())
					&& t.getSecurityId().equalsIgnoreCase(model.getSecurityId())
					&& t.getTransactionDate().equals(model.getTransactionDate())) {

				if ((t.getTransactionType().equalsIgnoreCase("SELL")
						&& model.getTransactionType().equalsIgnoreCase("BUY"))
						|| (t.getTransactionType().equalsIgnoreCase("BUY")
								&& model.getTransactionType().equalsIgnoreCase("SELL"))) {
					model.setMarketValue(model.getMarketValue() + transactionUtil.INTRADAY_TRANSACTION_CHARGE);
				}
			}

		});

	}

	public void NormalTransaction(TransactionModel model) {

		transactions.forEach(t -> {
			if (model.getExternalTransactionId().equalsIgnoreCase(t.getExternalTransactionId())) {
				if (t.getPriorityFlag().equalsIgnoreCase("Y")) {
					model.setMarketValue(t.getMarketValue() + transactionUtil.HIGH_PRIORITY_TRANSACTION_CHARGE);
				} else if (t.getPriorityFlag().equalsIgnoreCase("N") && t.getTransactionType().equalsIgnoreCase("SELL")
						&& t.getTransactionType().equalsIgnoreCase("WITHDRAW")) {
					model.setMarketValue(t.getMarketValue() + transactionUtil.NORMAL_PRIORITY_SELL_WITHDRAW);
				} else if (t.getPriorityFlag().equalsIgnoreCase("N") && t.getTransactionType().equalsIgnoreCase("BUY")
						&& t.getTransactionType().equalsIgnoreCase("DEPOSIT")) {
					model.setMarketValue(t.getMarketValue() + transactionUtil.NORMAL_PRIORITY_BUY_DEPOSIT);
				}
			}
		});

	}
	
	
	public TransactionModel readDataFromExcel()
	{
		
		TransactionModel model = new TransactionModel();
		
		List<TransactionModel> TransactionList = new ArrayList<TransactionModel>();
        try
        {
            String excelPath = "C:\\Jackson\\Employee.xlsx";
            FileInputStream fileInputStream = new FileInputStream(new File(excelPath));

            // Create Workbook instance holding .xls file
            XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);

            // Get the first worksheet
            XSSFSheet sheet = workbook.getSheetAt(0);

            // Iterate through each rows
            Iterator<?> rowIterator = sheet.iterator();
            
            
            while (rowIterator.hasNext())
            {
                // Get Each Row
                Row row = (Row) rowIterator.next();
                
                //Leaving the first row alone as it is header
                if(row.getRowNum() == 0)
                    continue;
                
                // Iterating through Each column of Each Row
                Iterator<?> cellIterator = row.cellIterator();
                
                
                while (cellIterator.hasNext())
                {
                    Object cell = cellIterator.next();
                    
                    int columnIndex = ((Cell) cell).getColumnIndex();
                    
                    switch (columnIndex+1)
                    {
                    case 1:
                        model.setExternalTransactionId(((Cell) cell).getStringCellValue());
                        break;
                    case 2:
                        model.setClientId(((Cell) cell).getStringCellValue());
                        break;
                    case 3:
                        model.setSecurityId(((Cell) cell).getStringCellValue());
                        break;
                    case 4:
                    	model.setTransactionType(((Cell) cell).getStringCellValue());
                    	break;
                    case 5:
                    	model.setTransactionDate(((Cell) cell).getDateCellValue());
                    	break;
                    case 6:
                    	model.setMarketValue(((Cell) cell).getNumericCellValue());
                    	break;
                    case 7:
                    	model.setPriorityFlag(((Cell) cell).getStringCellValue());
                    	break;
                    }
                }
                TransactionList.add(model);
            }
        } catch (IOException ie)
        {
            ie.printStackTrace();
        }
        return model;
    
    }

	public TransactionModel saveData() {
		TransactionModel transactionModel=readDataFromExcel();
		return transactionRepository.save(transactionModel);
	}

	@Override
	public TransactionModel getData(String externalTransactionId, String clientId, String securityId ) {
		TransactionModel transactionModel=transactionRepository.getData(externalTransactionId, clientId, securityId);
		return transactionModel;
	}
		
	
}
