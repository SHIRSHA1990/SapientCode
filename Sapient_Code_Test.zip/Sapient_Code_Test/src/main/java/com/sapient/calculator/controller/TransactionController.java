package com.sapient.calculator.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sapient.calculator.model.TransactionModel;
import com.sapient.calculator.repository.TransactionRepository;
import com.sapient.calculator.service.TransactionService;



@RestController
@RequestMapping("/sapient/transaction")
public class TransactionController {

	@Autowired
	private TransactionRepository transactionRepository;
	
	
	@Autowired
	private TransactionService transactionService;
	
	@GetMapping("/getData/{externalTransactionId},{clientId}, {securityId}")
	public ResponseEntity<?> getAllUsers(@PathVariable("externalTransactionId") String externalTransactionId,@PathVariable("clientId") String clientId,@PathVariable("securityId") String securityId ) {
		TransactionModel transactionModel=transactionRepository.getData(externalTransactionId, clientId, securityId);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	
	
}
