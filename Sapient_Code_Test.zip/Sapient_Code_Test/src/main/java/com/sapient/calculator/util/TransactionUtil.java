package com.sapient.calculator.util;

public class TransactionUtil {

	public final double INTRADAY_TRANSACTION_CHARGE=10.0;
	
	public final double HIGH_PRIORITY_TRANSACTION_CHARGE=500.0;
	
	public final double NORMAL_PRIORITY_SELL_WITHDRAW=100.0;
	
	public final double NORMAL_PRIORITY_BUY_DEPOSIT=50.0;
}
